/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ricardosandoval
 */
public class AdministracionController implements Initializable {

    @FXML
    public void btnCerrarSesion(ActionEvent event) throws Exception{
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Hasta pronto");
        alert.setHeaderText(null);
        alert.setContentText("Ha salido correctamente");
        alert.showAndWait();
        
        Parent root = FXMLLoader.load(PrincipalController.class.getResource("Principal.fxml"));
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    @FXML
    public void btnAgregarVuelo(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(AgregarController.class.getResource("Agregar.fxml"));
        Stage esc = new Stage();
        esc.setScene(new Scene (root));
        esc.initModality(Modality.WINDOW_MODAL);
        esc.initOwner(((Node)event.getSource()).getScene().getWindow());
        esc.show();
    }
    
    @FXML
    public void btnEditarVuelo(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(EditarController.class.getResource("Editar.fxml"));
        Stage esc = new Stage();
        esc.setScene(new Scene (root));
        esc.initModality(Modality.WINDOW_MODAL);
        esc.initOwner(((Node)event.getSource()).getScene().getWindow());
        esc.show();
    }
    
    @FXML
    public void btnReservarVuelo(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(ReservarController.class.getResource("Reservar.fxml"));
        Stage esc = new Stage();
        esc.setScene(new Scene (root));
        esc.initModality(Modality.WINDOW_MODAL);
        esc.initOwner(((Node)event.getSource()).getScene().getWindow());
        esc.show();
    }
    
    @FXML
    public void btnConsultarVuelo(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(AdministrarConsultaController.class.getResource("AdministrarConsulta.fxml"));
        Stage esc = new Stage();
        esc.setScene(new Scene (root));
        esc.initModality(Modality.WINDOW_MODAL);
        esc.initOwner(((Node)event.getSource()).getScene().getWindow());
        esc.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
