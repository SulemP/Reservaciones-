package aerupiicsa;

import aerupiicsa.Validaciones.validationTexto;
import static aerupiicsa.Validaciones.validationTexto.*;
import com.mysql.jdbc.MysqlDataTruncation;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date; 
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;


public class ReservarController implements Initializable, validationTexto {

    Conexion cc = new Conexion();
    Connection cn = cc.conectar();
    ObservableList<Vuelo> listaVuelos = FXCollections.observableArrayList();
    @FXML TableColumn colDestino;
    @FXML TableColumn colDescripcion;
    @FXML TableColumn colFecha;
    @FXML TableColumn colHora;
    @FXML TableColumn colZona;
    @FXML TextField txtBuscar;
    @FXML TextField txtNombre;
    @FXML TextField txtApellidos;
    @FXML TextField txtCorreo;
    @FXML TextField txtEdad;
    @FXML TableView tblVuelos;
    
    public void llenarDatosTabla(Connection connection, ObservableList<Vuelo> lista){
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select id_vue, dest, descr, fecha, hr_vue, descr_zona from Vuelos order by dest"

            );
                    
            while(resultado.next()){
                lista.add(
                        new Vuelo(
                                resultado.getInt("id_vue"),
                                resultado.getString("dest"),
                                resultado.getString("descr"),
                                resultado.getDate("fecha"),
                                resultado.getString("hr_vue"),
                                resultado.getString("descr_zona")
                        )
                );
            }
            cmd.close();
            resultado.close();
                    
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
    }
    
    @FXML
    public void btnReservarVuelo(ActionEvent e) throws Exception{
        Statement cmd = cn.createStatement();
        if(validarVacio(txtNombre.getText()) || validarVacio(txtApellidos.getText()) || validarVacio(txtCorreo.getText()) || validarVacio(txtEdad.getText())){
            //MUESTRA VENTANA DE ERROR
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Algo salió demasiado mal...");
            alert.setHeaderText(null);
            alert.setContentText("No introduciste los datos completos.");
            alert.showAndWait();
        }
        else{
            if(!validarCorreo(txtCorreo.getText())){
                //MUESTRA VENTANA DE ERROR
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Algo salió demasiado mal...");
                alert.setHeaderText(null);
                alert.setContentText("Tu email no tiene un formato válido");
                alert.showAndWait();
            } else{
                if(validar(txtNombre.getText()) || validar(txtApellidos.getText())){
                    //MUESTRA VENTANA DE ERROR
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("Tu nombre y apellidos no pueden llevar números");
                    alert.showAndWait();
                }
                else{
                if(tblVuelos.getSelectionModel().getSelectedIndex() == -1){
                    //MUESTRA VENTANA DE ERROR SI NO SELECCIONO NINGUN VUELO
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No seleccionaste ningún vuelo.");
                    alert.showAndWait();
                }
                else{
                //HACE EL INSERT DE LOS DATOS DEL CLIENTE Y EL VUELO A LA BASE DE DATOS
                try{
                cmd.execute("insert into Cliente (nom, ape, edad, mail, id_vue) values " +
                "('"+txtNombre.getText()+"', '"+txtApellidos.getText()+"', "+txtEdad.getText()+", '"+txtCorreo.getText()+"', "+listaVuelos.get(tblVuelos.getSelectionModel().getSelectedIndex()).getId()+" )"
                );
                //HACEMOS LA CONSULTA DE LOS DATOS DEL VUELO QUE RESERVÓ EL USUARIO
                ResultSet resultado = cmd.executeQuery("select * from Vuelos where id_vue = "+listaVuelos.get(tblVuelos.getSelectionModel().getSelectedIndex()).getId());
                resultado.next();
            
                //ESCRIBIMOS EL BOLETO CORRESPONDIENTE A LA RESERVACIÓN
                FileWriter fichero = new FileWriter("/Users/ricardosandoval/Desktop/Boleto "+txtNombre.getText()+" "+txtApellidos.getText()+".txt");
                PrintWriter pw = new PrintWriter(fichero);
                pw.println("---------------------------------------------------------------");
                pw.println("\t \t     A E R U P I I C S A\n\n  ");
                pw.println("\t \t \t \t\t #Vuelo: "+resultado.getInt("id_vue"));
                pw.println(txtNombre.getText()+ " " + txtApellidos.getText()); 
                pw.println("\t \t \t Destino: ");
                pw.println("\t \t \t "+resultado.getString("dest"));
                pw.println("\t \t \t "+resultado.getString("descr")+"\n");
                pw.println("\t Zona de despgue:\t "+resultado.getString("descr_zona")+"\n");
                pw.println("\t \t \t "+resultado.getString("hr_vue")+" hrs  ");
                pw.println("\t \t \t "+resultado.getDate("fecha")+"\n\n\n");
                pw.println("\t \t ¡QUE TENGAS UN BUEN VIAJE!");
                pw.println("----------------------------------------------------------------");
                //CERRAMOS LA ESCRITURA DEL ARCHIVO
                fichero.close();
            
                //MUESTRA VENTANA DE CONFIRMACION
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Confirmación");
                alert.setHeaderText(null);
                alert.setContentText("Se ha reservado su vuelo con éxito y su boleto se ha generado, ¡Buen viaje!");
                alert.showAndWait();
            
                //LIMPIA LOS CAMPOS DESPUÉS DE TODO PARA UN NUEVO REGISTRO
                txtNombre.clear();
                txtApellidos.clear();
                txtCorreo.clear();
                txtEdad.clear();
                listaVuelos.removeAll(listaVuelos);
                llenarDatosTabla(cn,listaVuelos);
                tblVuelos.setItems(listaVuelos);
                }
                catch(MySQLSyntaxErrorException ex){
                    System.err.println(ex);
                    //MUESTRA VENTANA DE ERROR SI NO SELECCIONO NINGUN VUELO
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No puedes introducir texto a la edad, solo números.");
                    alert.showAndWait();
                }
            }
            }   
        }
        }
    }
    
    @FXML
    public void btnBuscarDatos(ActionEvent e){
        //CAPTURA LA BUSQUEDA EN UN STRING
        String consulta = txtBuscar.getText();
        //EVALUA SÍ ES IGUAL A "TODO" PARA MOSTRAR TODOS LOS DATOS DE LA TABLA
        if(consulta.equals("todo") || consulta.equals("")){
            listaVuelos.removeAll(listaVuelos);
            llenarDatosTabla(cn,listaVuelos);
            tblVuelos.setItems(listaVuelos);
            txtBuscar.clear();
        }
        else{
            try{
                //REALIZA EL QUERY CON BASE A LA BUSQUEDA DEL USUARIO
                Statement cmd = cn.createStatement();
                ResultSet resultado = cmd.executeQuery("select * from Vuelos where dest = '"+consulta+"' "+
                            "or descr = '"+consulta+"' or fecha = '"+consulta+"' "+
                            "or hr_vue = '"+consulta+"' or descr_zona = '"+consulta+"'");
                //CONVIERTE EL RESULTADO DE LA CONSULTA (BOOL) A STRING
                String x = Boolean.toString(resultado.next());
                //SÍ ES IGUAL A "TRUE" SE ENCOTRÓ ALGO
                if(x.equals("true")){
                    //ELIMINAMOS LOS DATOS DE LA LISTA Y LOS LLENAMOS CON LAS DEL QUERY RESULTANTE
                    listaVuelos.removeAll(listaVuelos);
                    do{
                        listaVuelos.add(
                            new Vuelo(
                                resultado.getInt("id_vue"),
                                resultado.getString("dest"),
                                resultado.getString("descr"),
                                resultado.getDate("fecha"),
                                resultado.getString("hr_vue"),
                                resultado.getString("descr_zona")
                            )
                        );
                    }while(resultado.next());
                    cmd.close();
                    resultado.close();
                    //ASIGNAMOS LA NUEVA LISTA A LA TABLA PARA QUE EL USUARIO VEA EL RESULTADO DE SU BUSQUEDA
                    tblVuelos.setItems(listaVuelos);
                }
                else{
                    //VENTANA DE QUE NO EXISTE EL VUELO EN LA BASE DE DATOS
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No existe ningún vuelo con esos detalles en la base de datos");
                    alert.showAndWait();
                }
            }
            catch(SQLException ex){
                System.out.println(ex);
            }
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //LLENAMOS LOS DATOS A LA LISTA DESDE LA BASE DE DATOS
        llenarDatosTabla(cn,listaVuelos);
        tblVuelos.setItems(listaVuelos);
        
        
        //CONECTAMOS LOS DATOS A LAS COLUMNAS DE LA TABLA
        colDestino.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Destino"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Descripcion"));
        colFecha.setCellValueFactory(new PropertyValueFactory<Vuelo, Date> ("Fecha"));
        colHora.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Hora"));
        colZona.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Zona"));
    }    
    
}
