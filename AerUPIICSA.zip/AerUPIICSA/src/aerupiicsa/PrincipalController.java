/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import aerupiicsa.login.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author ricardosandoval
 */
public class PrincipalController implements Initializable {
    
    @FXML
    public void btnAdministrarVuelos(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(LoginController.class.getResource("Login.fxml"));
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    @FXML
    public void btnReservarVuelo(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(ReservarController.class.getResource("Reservar.fxml"));
        Stage esc = new Stage();
        esc.setScene(new Scene (root));
        esc.initModality(Modality.WINDOW_MODAL);
        esc.initOwner(((Node)event.getSource()).getScene().getWindow());
        esc.show();
    }
    
    @FXML
    public void btnConsultarVuelo(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(ConsultarController.class.getResource("Consultar.fxml"));
        Stage esc = new Stage();
        esc.setScene(new Scene (root));
        esc.initModality(Modality.WINDOW_MODAL);
        esc.initOwner(((Node)event.getSource()).getScene().getWindow());
        esc.show();
    }
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
