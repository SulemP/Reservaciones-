/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa.login;

/**
 *
 * @author ricardosandoval
 */
public class User {
    private String Usuario;
    private String Contraseña;
    private String Nombre;
    
    public User(String usuario, String contraseña, String nombre){
        this.Usuario = usuario;
        this.Contraseña = contraseña;
        this.Nombre = nombre;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String usuario) {
        this.Usuario = usuario;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String contraseña) {
        this.Contraseña = contraseña;
    }
    
    
}
