
package aerupiicsa.login;

import aerupiicsa.AdministracionController;
import aerupiicsa.Conexion;
import aerupiicsa.EditarController;
import aerupiicsa.PrincipalController;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ricardosandoval
 */
public class LoginController implements Initializable {

    @FXML TextField txtUsuario;
    @FXML TextField txtContraseña;
    
    @FXML
    public void btnAtras(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(PrincipalController.class.getResource("Principal.fxml"));
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
    }
    
    @FXML
    public void login(ActionEvent e) throws Exception{
        Conexion cc = new Conexion();
        Connection cn = cc.conectar();
        try{
                Statement cmd = cn.createStatement();
                ResultSet resultado = cmd.executeQuery("select * from Usuario where usuario = '"+txtUsuario.getText()+"' "+
                            "and pass = '"+txtContraseña.getText()+"'");
                String x = Boolean.toString(resultado.next());
                
                if(x.equals("true")){
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Bienvenido");
                    alert.setHeaderText(null);
                    alert.setContentText("Se inició sesión correctamente");
                    alert.showAndWait();
                    cmd.close();
                    resultado.close();
                    Parent root = FXMLLoader.load(AdministracionController.class.getResource("Administracion.fxml"));
                    Stage stage = (Stage)((Node) e.getSource()).getScene().getWindow();
                    stage.setScene(new Scene(root));
                }
                else{
                    //VENTANA DE QUE NO EXISTE EL USUARIO y CONTRASEÑA EN LA BASE DE DATOS
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error fatal");
                    alert.setHeaderText(null);
                    alert.setContentText("Acceso denegado");
                    alert.showAndWait();
                    txtUsuario.setText("");
                    txtContraseña.setText("");
                }
            }
            catch(SQLException ex){
                System.out.println(ex);
            }
        cn.close();
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
