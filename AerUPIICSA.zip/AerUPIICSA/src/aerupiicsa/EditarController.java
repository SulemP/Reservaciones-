/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import static aerupiicsa.Validaciones.validationTexto.validar;
import static aerupiicsa.Validaciones.validationTexto.validarVacio;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.ChoiceBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

/**
 * FXML Controller class
 *
 * @author ricardosandoval
 */
public class EditarController implements Initializable {

    ObservableList<Vuelo> listaVuelos = FXCollections.observableArrayList();
    ObservableList<String> listaHora = FXCollections.observableArrayList();
    ObservableList<Date> listaFecha = FXCollections.observableArrayList();
    ObservableList<String> listaZona = FXCollections.observableArrayList();
    
    Conexion cc = new Conexion();
    Connection cn = cc.conectar();
    
    @FXML TableView tblVuelos;
    @FXML TableColumn colDestino;
    @FXML TableColumn colDescripcion;
    @FXML TableColumn colFecha;
    @FXML TableColumn colHora;
    @FXML TableColumn colZona;
    @FXML TextField txtBuscar;
    
    @FXML
    public void btnBuscarDatos(ActionEvent e){
        String consulta = txtBuscar.getText();
        if(consulta.equals("todo")){
            listaVuelos.removeAll(listaVuelos);
            llenarDatosTabla(cn,listaVuelos);
            tblVuelos.setItems(listaVuelos);
            txtBuscar.clear();
        }
        else{
            try{
                Statement cmd = cn.createStatement();
                ResultSet resultado = cmd.executeQuery("select * from Vuelos where dest = '"+consulta+"' "+
                            "or descr = '"+consulta+"' or fecha = '"+consulta+"' "+
                            "or hr_vue = '"+consulta+"' or descr_zona = '"+consulta+"'");
                String x = Boolean.toString(resultado.next());
                
                if(x.equals("true")){
                    listaVuelos.removeAll(listaVuelos);
                    do{
                        listaVuelos.add(
                            new Vuelo(
                                resultado.getInt("id_vue"),
                                resultado.getString("dest"),
                                resultado.getString("descr"),
                                resultado.getDate("fecha"),
                                resultado.getString("hr_vue"),
                                resultado.getString("descr_zona")
                            )
                        );
                    }while(resultado.next());
                    cmd.close();
                    resultado.close();
                    tblVuelos.setItems(listaVuelos);
                }
                else{
                    //VENTANA DE QUE NO EXISTE EL VUELO EN LA BASE DE DATOS
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No existe ningún vuelo con esos detalles en la base de datos");
                    alert.showAndWait();
                }
            }
            catch(SQLException ex){
                System.out.println(ex);
            }
        }
    }
    
    @FXML
    public void btnEliminarDatos(ActionEvent e) throws SQLException{
        if(tblVuelos.getSelectionModel().getSelectedIndex() == -1){
            //VENTANA QUE NO HA SELECCIONADO NADA EN LA TABLA
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Algo salió demasiado mal...");
            alert.setHeaderText(null);
            alert.setContentText("Selecciona el vuelo que quieres eliminar");
            alert.showAndWait();
        }
        else{
        try{
            //SE HACE LA INSTRUCCION DE DELETE CON EL DESTINO 
            Statement cmd = cn.createStatement();
            cmd.execute(
                "delete Vuelos from Vuelos where id_vue = "+listaVuelos.get(tblVuelos.getSelectionModel().getSelectedIndex()).getId()
            );
            
            cmd.execute(
                    "alter table Vuelos auto_increment = 1"
            );

            //MUESTRA VENTANA DE CONFIRMACION
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmación");
            alert.setHeaderText(null);
            alert.setContentText("Se eliminó el vuelo con éxito");
            alert.showAndWait();
        
            
            listaVuelos.removeAll(listaVuelos); //REMUEVE ELEMENTOS DE LA LISTA
            llenarDatosTabla(cn,listaVuelos); //SE VUELVEN A CAPTURAR LOS CAMPOS DE LA BD
            tblVuelos.refresh(); //ACTUALIZA LOS DATOS DE LA TABLA
            txtBuscar.clear();
            cmd.close();
        } 
        catch(MySQLIntegrityConstraintViolationException ex){
            //VENTANA DE QUE YA SE HAN RESERVADO ESTE VUELO
            System.out.println(ex);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Algo salió demasiado mal...");
            alert.setHeaderText(null);
            alert.setContentText("Clientes ya han reservado éste vuelo, no lo puedes eliminar");
            alert.showAndWait();
        }
        }
    }
    
    public void llenarDatosTabla(Connection connection, ObservableList<Vuelo> lista){
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select id_vue, dest, descr, fecha, hr_vue, descr_zona from Vuelos order by dest"

            );
                    
            while(resultado.next()){
                lista.add(
                        new Vuelo(
                                resultado.getInt("id_vue"),
                                resultado.getString("dest"),
                                resultado.getString("descr"),
                                resultado.getDate("fecha"),
                                resultado.getString("hr_vue"),
                                resultado.getString("descr_zona")
                        )
                );
            }
            cmd.close();
            resultado.close();
                    
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
    }
    
    //FUNCIONES PARA AGREGAR DATOS DE SQL A LOS COMBOBOX
    public void llenarComboBoxHora(Connection connection, ObservableList<String> lista){
        
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select * from Hora"
            );
                
            while(resultado.next()){
                lista.add(resultado.getString("hr_vue"));
            }
            resultado.close();
            cmd.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
        
    }
    
    public void llenarComboBoxZona(Connection connection, ObservableList<String> lista){
        
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select descr_zona from Zona"
            );
                
            while(resultado.next()){
                lista.add(resultado.getString("descr_zona"));
            }
            resultado.close();
            cmd.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
        
    }
    
    public void llenarComboBoxFecha(Connection connection, ObservableList<Date> lista){
        
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select * from Fecha"
            );
                
            while(resultado.next()){
                lista.add(resultado.getDate("fecha"));//.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
                //lista.add(resultado.getDate("fecha"));
            }
            resultado.close();
            cmd.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
        
    }
 

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //LLENAMOS LOS DATOS A LA LISTA DESDE LA BASE DE DATOS
        llenarDatosTabla(cn,listaVuelos);
        llenarComboBoxHora(cn,listaHora);
        llenarComboBoxFecha(cn,listaFecha);
        llenarComboBoxZona(cn,listaZona);
    
        
        //CONECTAMOS LOS DATOS A LAS COLUMNAS DE LA TABLA
        colDestino.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Destino"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Descripcion"));
        colFecha.setCellValueFactory(new PropertyValueFactory<Vuelo, Date> ("Fecha"));
        colHora.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Hora"));
        colZona.setCellValueFactory(new PropertyValueFactory<Vuelo, String> ("Zona"));
        
        //AGREGAR ELEMENTOS A LA TABLA
        tblVuelos.setItems(listaVuelos);
                
        
        //EDICION DE LOS CAMPOS POR DOBLE CLIC, DESTINO
        tblVuelos.setEditable(true);
        colDestino.setCellFactory(TextFieldTableCell.forTableColumn());
        colDestino.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Vuelo,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Vuelo,String> t){
                        if(validarVacio(t.getNewValue()) || validar(t.getNewValue())){
                            //MUESTRA VENTANA DE ERROR
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Algo salió demasiado mal...");
                            alert.setHeaderText(null);
                            alert.setContentText("Formato incorrecto, vuelve a intentarlo.");
                            alert.showAndWait();
                            tblVuelos.refresh();
                        } else{
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Vuelos set dest= '"+t.getNewValue()+"' where id_vue= "+listaVuelos.get(t.getTablePosition().getRow()).getId()
                                    
                            );
                            cmd.close();
                        ((Vuelo)t.getTableView().getItems().get(t.getTablePosition().getRow())).setDestino(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                        }
                        
                    }
                }
        );
        
        //EDICION DE LOS CAMPOS POR DOBLE CLIC, DESCRIPCION
        colDescripcion.setCellFactory(TextFieldTableCell.forTableColumn());
        colDescripcion.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Vuelo,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Vuelo,String> t){
                        if(validarVacio(t.getNewValue()) || validar(t.getNewValue())){
                            //MUESTRA VENTANA DE ERROR
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Algo salió demasiado mal...");
                            alert.setHeaderText(null);
                            alert.setContentText("Formato incorrecto, vuelve a intentarlo.");
                            alert.showAndWait();
                            tblVuelos.refresh();
                        } else{
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Vuelos set descr= '"+t.getNewValue()+"' where id_vue= "+listaVuelos.get(t.getTablePosition().getRow()).getId()

                            );
                            cmd.close();
                            
                        ((Vuelo)t.getTableView().getItems().get(t.getTablePosition().getRow())).setDescripcion(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                        }
                    }
                }
        );
        
        //EDICION DE LOS CAMPOS POR CHOICEBOX, FECHA
        colFecha.setCellFactory(ChoiceBoxTableCell.forTableColumn(listaFecha));
        colFecha.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Vuelo,Date>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Vuelo,Date> t){
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Vuelos set fecha= '"+t.getNewValue()+"' where id_vue= "+listaVuelos.get(t.getTablePosition().getRow()).getId()

                            );
                            cmd.close();
                        ((Vuelo)t.getTableView().getItems().get(t.getTablePosition().getRow())).setFecha(t.getNewValue());
                            
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                        
                    }
                }
        );
        
        //EDICION DE LOS CAMPOS POR CHOICEBOX, HORA
        colHora.setCellFactory(ChoiceBoxTableCell.forTableColumn(listaHora));
        colHora.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Vuelo,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Vuelo,String> t){
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Vuelos set hr_vue= '"+t.getNewValue()+"' where id_vue= "+listaVuelos.get(t.getTablePosition().getRow()).getId()

                            );
                            cmd.close();
                        ((Vuelo)t.getTableView().getItems().get(t.getTablePosition().getRow())).setHora(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                    }
                }
        );
        
        //EDICION DE LOS CAMPOS POR CHOICEBOX, ZONA
        colZona.setCellFactory(ChoiceBoxTableCell.forTableColumn(listaZona));
        colZona.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Vuelo,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Vuelo,String> t){
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Vuelos set descr_zona= '"+t.getNewValue()+"' where id_vue= "+listaVuelos.get(t.getTablePosition().getRow()).getId()

                            );
                            cmd.close();
                            
                        ((Vuelo)t.getTableView().getItems().get(t.getTablePosition().getRow())).setZona(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                    }
                }
        );
    }    


    
}
