package aerupiicsa;

import aerupiicsa.Validaciones.validationTexto;
import static aerupiicsa.Validaciones.validationTexto.validar;
import static aerupiicsa.Validaciones.validationTexto.validarVacio;
import com.mysql.jdbc.MysqlDataTruncation;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;


public class AgregarController implements Initializable, validationTexto {

    
    @FXML TextField txtDestino;
    @FXML TextField txtDescripcion;
    @FXML ComboBox CBFecha;
    @FXML ComboBox CBHora;
    @FXML ComboBox CBZona;
    @FXML RadioButton RBNuevaFecha;
    @FXML DatePicker DateFecha;
    
    ObservableList<String> listaHora = FXCollections.observableArrayList();
    ObservableList<String> listaZona = FXCollections.observableArrayList();
    ObservableList<Date> listaFecha = FXCollections.observableArrayList();
    
    Conexion cc = new Conexion();
    Connection cn = cc.conectar();
    
    public void actualizarVentana (){
        listaFecha.removeAll(listaFecha); //REMUEVE ELEMENTOS DE LA LISTA
        llenarComboBoxFecha(cn,listaFecha); //SE VUELVEN A CAPTURAR LOS CAMPOS DE LA BD
        CBFecha.setItems(listaFecha);//ACTUALIZA LOS DATOS DE LA TABLA
        txtDestino.setText("");
        txtDescripcion.setText("");
        CBHora.setValue("");
        CBFecha.setValue("");
        CBZona.setValue("");
        DateFecha.setDisable(true);
        RBNuevaFecha.setSelected(false);
        CBFecha.setDisable(false);
        
    }
    //FUNCION DEL RADIOBUTTION PARA AGREGAR UNA NUEVA FECHA
    @FXML
    public  void AgregarNuevaFecha(ActionEvent e){
        
        if(RBNuevaFecha.isSelected() == true){
            CBFecha.setDisable(true);
            DateFecha.setDisable(false);
        }
        else{
            CBFecha.setDisable(false);
            DateFecha.setDisable(true);
        }
        
    }
    
    //FUNCIONES DE LOS BOTONES
    @FXML
    public void btnAgregarVuelo(ActionEvent e) throws Exception{
        Statement cmd = cn.createStatement();
        //EXTRAER DATOS DE LOS CAMPOS
        if(RBNuevaFecha.isSelected() == true){
            //COMPRUEBA SÍ INTRODUJO DATOS
            if(validarVacio(txtDestino.getText())  || validarVacio(txtDescripcion.getText()) || CBZona.getSelectionModel().isEmpty() || CBHora.getSelectionModel().isEmpty() || DateFecha.getValue() == null){
                //MUESTRA VENTANA DE ERROR
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Algo salió demasiado mal...");
                alert.setHeaderText(null);
                alert.setContentText("No introduciste los datos completos.");
                alert.showAndWait();
            } 
            //REALIZA EL QUERY DE AGREGAR LA NUEVA FECHA Y EL VUELO A LA TABLA
            else{
                if(validar(txtDestino.getText()) || validar(txtDescripcion.getText())){
                    //MUESTRA VENTANA DE ERROR
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No puedes introducir números en Destino/Descripción");
                    alert.showAndWait();
                } else{
                try{
                    //AGREGA PRIMERO LA FECHA A LA TABLA DE LA BASE DE DATOS
                    cmd.execute("insert into Fecha values ('"+DateFecha.getValue()+"')");
                
                    //DESPUES AGREGA LOS DATOS DEL VUELO A LA BASE DE DATOS
                    cmd.execute("insert into Vuelos (dest,descr,fecha,hr_vue,descr_zona) values ('"+txtDestino.getText()+
                                "','"+txtDescripcion.getText()+"','"+DateFecha.getValue()+"','"+CBHora.getValue()+"','"+CBZona.getValue()+"')");
            
                    //MUESTRA VENTANA DE CONFIRMACION
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Confirmación");
                    alert.setHeaderText(null);
                    alert.setContentText("Se registró correctamente");
                    alert.showAndWait();
                    actualizarVentana();
                    
                }
                catch(MySQLIntegrityConstraintViolationException ex){
                    //MUESTRA VENTANA DE ERROR
                    System.out.println(ex);
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("La fecha que introduciste ya existe en la base de datos, no es necesario volver a agregarla");
                    alert.showAndWait();
                }
                }
            }
        }
        else{
            //COMPRUEBA SÍ INTRODUJO DATOS
            if(validarVacio(txtDestino.getText())  || validarVacio(txtDescripcion.getText()) || CBZona.getSelectionModel().isEmpty() || CBHora.getSelectionModel().isEmpty() || CBFecha.getSelectionModel().isEmpty()){
                //MUESTRA VENTANA DE ERROR
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Algo salió demasiado mal...");
                alert.setHeaderText(null);
                alert.setContentText("No introduciste los datos completos.");
                alert.showAndWait();
            } 
            else{
                if(validar(txtDestino.getText()) || validar(txtDescripcion.getText())){
                    //MUESTRA VENTANA DE ERROR
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No puedes introducir números en Destino/Descripción");
                    alert.showAndWait();
                } else{
                //REALIZA EL QUERY DE AGREGAR VUELO A LA TABLA
                try{
                    //AGREGA LOS DATOS DEL VUELO A LA BASE DE DATOS
                    cmd.execute("insert into Vuelos (dest,descr,fecha,hr_vue,descr_zona) values ('"+txtDestino.getText()+
                                "','"+txtDescripcion.getText()+"','"+CBFecha.getValue()+"','"+CBHora.getValue()+"','"+CBZona.getValue()+"')");
                    //MUESTRA VENTANA DE CONFIRMACION
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Confirmación");
                    alert.setHeaderText(null);
                    alert.setContentText("Se registró correctamente");
                    alert.showAndWait();
                    actualizarVentana();
                }
                catch(SQLException ex){
                    
                }
                }
            }
            cmd.close();
        }
    }
    
    
    //FUNCIONES PARA AGREGAR DATOS DE SQL A LOS COMBOBOX
    public void llenarComboBoxHora(Connection connection, ObservableList<String> lista){
        
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select * from Hora"
            );
                
            while(resultado.next()){
                lista.add(resultado.getString("hr_vue"));
            }
            resultado.close();
            cmd.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
        
    }
    
    public void llenarComboBoxZona(Connection connection, ObservableList<String> lista){
        
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select descr_zona from Zona"
            );
                
            while(resultado.next()){
                lista.add(resultado.getString("descr_zona"));
            }
            resultado.close();
            cmd.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
        
    }
    
    public void llenarComboBoxFecha(Connection connection, ObservableList<Date> lista){
        
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select * from Fecha"
            );
                
            while(resultado.next()){
                lista.add(resultado.getDate("fecha"));//.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
                //lista.add(resultado.getDate("fecha"));
            }
            resultado.close();
            cmd.close();
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //CONECTAMOS LOS CAMPOS DE LA BASE DE DATOS A LOS COMBOBOX
        llenarComboBoxHora(cn,listaHora);
        CBHora.setItems(listaHora);
        
        llenarComboBoxZona(cn,listaZona);
        CBZona.setItems(listaZona);
        
        llenarComboBoxFecha(cn,listaFecha);
        CBFecha.setItems(listaFecha);
        
        
        //
        
    }    
    
}
