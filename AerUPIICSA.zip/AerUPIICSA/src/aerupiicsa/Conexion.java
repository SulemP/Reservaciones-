/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author ricardosandoval
 */
public class Conexion {
    private static String db = "AerUPIICSA";
    private static String user = "root";
    private static String pass = "root";
    private static String host = "localhost:8889";
    private static String server = "jdbc:mysql://"+host+"/"+db;
    
    
    
    public Connection conectar(){

        Connection cn=null;
        try{

            Class.forName("com.mysql.jdbc.Driver");
            cn=DriverManager.getConnection(server,user,pass);

        }catch(Exception e){ System.out.println(e);}
         return cn;

    }
}
