
package aerupiicsa;

import java.util.Date;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;


public class Vuelo {
    private SimpleIntegerProperty id;
    private SimpleStringProperty Destino;
    private SimpleStringProperty Descripcion;
    private SimpleObjectProperty <Date> Fecha;
    private SimpleStringProperty Hora;
    private SimpleStringProperty Zona;
    
    public Vuelo(int id, String Destino, String Descripcion, Date Fecha, String Hora, String Zona){
        this.id = new SimpleIntegerProperty(id);
        this.Destino = new SimpleStringProperty(Destino);
        this.Descripcion = new SimpleStringProperty (Descripcion);
        this.Fecha = new SimpleObjectProperty (Fecha);
        this.Hora = new SimpleStringProperty (Hora);
        this.Zona = new SimpleStringProperty (Zona);
    }

    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getDestino() {
        return Destino.get();
    }

    public void setDestino(String Destino) {
        this.Destino.set(Destino);
    }

    public String getDescripcion() {
        return Descripcion.get();
    }

    public void setDescripcion(String Descripción) {
        this.Descripcion.set(Descripción);
    }

    public Date getFecha() {
        return Fecha.get();
    }

    public void setFecha(Date Fecha) {
        this.Fecha.set(Fecha);
    }

    public String getHora() {
        return Hora.get();
    }

    public void setHora(String Hora) {
        this.Hora.set(Hora);
    }

    public String getZona() {
        return Zona.get();
    }

    public void setZona(String Zona) {
        this.Zona.set(Zona);
    }
    
    
}
