/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author ricardosandoval
 */
class Persona {
    
    SimpleStringProperty Nombre;
    SimpleStringProperty Apellidos;
    SimpleIntegerProperty Edad;

    public Persona(String nombre, String apellidos, int edad) {
        this.Nombre = new SimpleStringProperty(nombre);
        this.Apellidos = new SimpleStringProperty(apellidos);
        this.Edad = new SimpleIntegerProperty(edad);
    }

    public String getNombre() {
        return Nombre.get();
    }

    public void setNombre(String Nombre) {
        this.Nombre.set(Nombre);
    }

    public String getApellidos() {
        return Apellidos.get();
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos.set(Apellidos);
    }

    public int getEdad() {
        return Edad.get();
    }

    public void setEdad(int Edad) {
        this.Edad.set(Edad);
    }
    
}
