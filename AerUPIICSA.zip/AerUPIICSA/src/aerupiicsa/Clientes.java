/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author ricardosandoval
 */
public class Clientes extends Persona{
    private SimpleIntegerProperty IdCliente;
    private SimpleStringProperty Contacto;
    private SimpleIntegerProperty IdVuelo;

    
    public Clientes(int IdCliente, String Nombre, String Apellidos, int Edad, String Contacto, int IdVuelo) {
        super(Nombre,Apellidos,Edad);
        this.IdCliente = new SimpleIntegerProperty(IdCliente);
        this.Contacto = new SimpleStringProperty(Contacto);
        this.IdVuelo = new SimpleIntegerProperty(IdVuelo);
    }
    
    

    public int getIdCliente() {
        return IdCliente.get();
    }

    public void setIdCliente(int IdCliente) {
        this.IdCliente.set(IdCliente);
    }
    
    public String getContacto() {
        return Contacto.get();
    }

    public void setContacto(String Contacto) {
        this.Contacto.set(Contacto);
    }

    public int getIdVuelo() {
        return IdVuelo.get();
    }

    public void setIdVuelo(int IdVuelo) {
        this.IdVuelo.set(IdVuelo);
    }
    
}
