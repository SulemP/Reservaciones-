/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa.Validaciones;

import java.math.BigDecimal;
import java.text.NumberFormat;
import javafx.event.Event;
import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.NumberStringConverter;

/**
 *
 * @author ricardosandoval
 * @param <T>
 */
public class EditableIntegerTableCell<T> extends TableCell<T, Integer> {
    
    private TextField textField;
    private int minDecimal, maxDecimal;
    
    public EditableIntegerTableCell(){
        minDecimal = 0;
        maxDecimal = 0;
    }

    public EditableIntegerTableCell(int minDecimal, int maxDecimal) {
        this.minDecimal = minDecimal;
        this.maxDecimal = maxDecimal;
    }
    
    @Override
    public void startEdit(){
        if(editableProperty().get()){
            if(!isEmpty()){
                super.startEdit();
                createTextField();
                setText(null);
                setGraphic(textField);
                textField.requestFocus();
            }
        }
    }
    
    @Override
    public void cancelEdit(){
        super.cancelEdit();
        setText(getItem() != null ? getItem().toString() : null);
        setGraphic(null);
    }
    
    @Override
    public void updateItem(Integer item, boolean empty){
        super.updateItem(item,empty);
        if(empty){
            setText(null);
            setGraphic(null);
        } else {
            if(isEditing()){
                if(textField != null){
                    textField.setText(getString());
                    textField.selectAll();
                }
                setText(null);
                setGraphic(textField);
            } else {
                setText(getString());
                setGraphic(null);
            }
        }
    }
    
    private void createTextField(){
        textField = new TextField();
        textField.setTextFormatter(new DecimalTextFormatter(0, 0));
        textField.setText(getString());

        textField.setOnAction(evt -> {
            if(textField.getText() != null && !textField.getText().isEmpty()){
                NumberStringConverter nsc = new NumberStringConverter();
                Number n = nsc.fromString(textField.getText());
                commitEdit(Integer.valueOf(n.intValue()));
            }
        });
        textField.setMinWidth(this.getWidth() - this.getGraphicTextGap() * 2);

        textField.setOnKeyPressed((ke) -> {
            if (ke.getCode().equals(KeyCode.ESCAPE)) {
                cancelEdit();
            }
        });

        textField.setAlignment(Pos.CENTER_RIGHT);
        this.setAlignment(Pos.CENTER_RIGHT);
    }
    
    private String getString(){
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMinimumFractionDigits(minDecimal);
        nf.setMaximumFractionDigits(maxDecimal);
        return getItem() == null ? "" : nf.format(getItem());
    }
    
    
    @Override
    public void commitEdit(Integer item) {
        if (isEditing()) {
            super.commitEdit(item);
        } else {
            final TableView<T> table = getTableView();
            if (table != null) {
                TablePosition<T, Integer> position = new TablePosition<T, Integer>(getTableView(),
                        getTableRow().getIndex(), getTableColumn());
                CellEditEvent<T, Integer> editEvent = new CellEditEvent<T, Integer>(table, position,
                        TableColumn.editCommitEvent(), item);
                Event.fireEvent(getTableColumn(), editEvent);
            }
            updateItem(item, false);
            if (table != null) {
                table.edit(-1, null);
            }

        }
    }

}


