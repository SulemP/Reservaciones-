/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa.Validaciones;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.scene.control.Alert;

/**
 *
 * @author ricardosandoval
 */
public interface validationTexto {
 
    public static boolean validar(String texto){
        Pattern pat = Pattern.compile("[0-9]");
        Matcher mat = pat.matcher(texto);
        
        if(texto.isEmpty() || mat.find()){
            return true;
        }
        else{
            return false;
        }
    }
    
    public static boolean validarCorreo(String correo){
        String expresion = "[^@]+@[^@]+\\.[a-zA-Z]{2,}";
        
        if(Pattern.matches(expresion, correo)){
            return true;
        } else{
            return false;
        }
    }
    
    public static boolean validarVacio(String texto){
        
        if(texto.isEmpty()){
            return true;
        }
        else{
            return false;
        }
    }
    
}
