/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author ricardosandoval
 */
public class ConsultarController implements Initializable {

    Conexion cc = new Conexion();
    Connection cn = cc.conectar();
    ObservableList<Clientes> listaClientes = FXCollections.observableArrayList();
    ObservableList<Vuelo> listaVuelos = FXCollections.observableArrayList();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    @FXML TableView tblClientes;
    @FXML TableColumn colNombre;
    @FXML TableColumn colIdVuelo;
    @FXML TableColumn colApellidos;
    @FXML TableColumn colContacto;
    @FXML TableColumn colEdad;
    @FXML TextField txtBuscar;
    @FXML TextField txtNombre;
    @FXML TextField txtContacto;
    @FXML TextField txtDestino;
    @FXML TextField txtDescripcion;
    @FXML TextField txtIdVuelo;
    @FXML TextField txtFecha;
    @FXML TextField txtHora;
    @FXML TextField txtZona;
    @FXML Button btnImprimir;
    
    
    
    @FXML
    public void btnImprimirBoleto(ActionEvent e) throws IOException{
        //SE GENERA EL BOLETO CORRESPONDIENTE A LA RESERVACIÓN
        FileWriter fichero = new FileWriter("/Users/ricardosandoval/Desktop/Boleto "+txtNombre.getText()+".txt");
        PrintWriter pw = new PrintWriter(fichero);
        pw.println("---------------------------------------------------------------");
        pw.println("\t \t     A E R U P I I C S A\n\n  ");
        pw.println("\t \t \t \t\t #Vuelo: "+txtIdVuelo.getText());
        pw.println(txtNombre.getText());
        pw.println("\t \t \t Destino: ");
        pw.println("\t \t \t "+txtDestino.getText());
        pw.println("\t \t \t "+txtDescripcion.getText()+"\n");
        pw.println("\t Zona de despgue:\t "+txtZona.getText()+"\n");
        pw.println("\t \t \t "+txtHora.getText()+" hrs  ");
        pw.println("\t \t \t "+txtFecha.getText()+"\n\n\n");
        pw.println("\t \t ¡QUE TENGAS UN BUEN VIAJE!");
        pw.println("----------------------------------------------------------------");
        //SE CIERRA EL ARCHIVO ESCRITO
        fichero.close();
        //VENTANA DE CONFIRMACIÓN 
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        alert.setContentText("Se ha impreso el boleto");
        alert.showAndWait();
        
        //LIMPIA TODOS LOS CAMPOS PARA UNA NUEVA IMPRESIÓN DE BOLETO
        txtNombre.clear();
        txtContacto.clear();
        txtDestino.clear();
        txtDescripcion.clear();
        txtIdVuelo.clear();
        txtFecha.clear();
        txtHora.clear();
        txtZona.clear();
        btnImprimir.setDisable(true);
    }
    
    @FXML
    public void btnConsultarDatos(ActionEvent e) throws SQLException{
        if(tblClientes.getSelectionModel().getSelectedIndex() == -1){
            //VENTANA DE QUE NO SELECCIONO NADA EN LA TABLA
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Algo salió demasiado mal...");
            alert.setHeaderText(null);
            alert.setContentText("Selecciona al cliente que quieres consultar.");
            alert.showAndWait();
        }
        else{
            //SE ASIGNAN LOS VALORES CORRESPONDIENTES DEL USUARIO A LOS TEXTFIELD
            txtNombre.setText(listaClientes.get(tblClientes.getSelectionModel().getSelectedIndex()).getNombre() + " "
                             +listaClientes.get(tblClientes.getSelectionModel().getSelectedIndex()).getApellidos());
            txtContacto.setText(listaClientes.get(tblClientes.getSelectionModel().getSelectedIndex()).getContacto());
            txtIdVuelo.setText(Integer.toString(listaClientes.get(tblClientes.getSelectionModel().getSelectedIndex()).getIdVuelo()));
            //QUERY PARA OBTENER LOS DATOS DEL VUELO DE LA BASE DE DATOS
            Statement cmd = cn.createStatement();
            ResultSet resultado = cmd.executeQuery("select * from Vuelos where id_vue = "+(listaClientes.get(tblClientes.getSelectionModel().getSelectedIndex()).getIdVuelo()));
            resultado.next();
            //ASIGNAR LA TABLA DEL QUERY A LOS TEXTFIELD DEL VUELO
            txtDestino.setText(resultado.getString("dest"));
            txtDescripcion.setText(resultado.getString("descr"));
            txtFecha.setText(sdf.format(resultado.getDate("fecha")));
            txtHora.setText(resultado.getString("hr_vue"));
            txtZona.setText(resultado.getString("descr_zona"));
            btnImprimir.setDisable(false);
        }
    }
    
    
    public void llenarDatosTabla(Connection connection, ObservableList<Clientes> lista){
        try{
            Statement cmd = connection.createStatement();
            ResultSet resultado = cmd.executeQuery(
                    "select id_clie, nom, ape, edad, mail, id_vue from Cliente order by nom"

            );
            while(resultado.next()){
                lista.add(
                        new Clientes(
                                resultado.getInt("id_clie"),
                                resultado.getString("nom"),
                                resultado.getString("ape"),
                                resultado.getInt("edad"),
                                resultado.getString("mail"),
                                resultado.getInt("id_vue")
                        )
                );
            }
            cmd.close();
            resultado.close();
                    
        }
        catch (SQLException ex){
            System.err.println(ex);
        }
    }
    
    
    @FXML
    public void btnBuscarDatos(ActionEvent e){
        //SE CAPTURA LA BUSQUEDA
        String consulta = txtBuscar.getText();
        //SE EVALÚA SÍ ES IGUAL A "TODO" PARA MOSTRAR TODOS LOS DATOS
        if(consulta.equals("todo")||consulta.equals("")){
            listaClientes.removeAll(listaClientes);
            llenarDatosTabla(cn,listaClientes);
            tblClientes.setItems(listaClientes);
            txtBuscar.clear();
        }
        else{
            try{
                //REALIZAR QUERY PARA OBTENER LA BÚSQUEDA DEL USUARIO
                Statement cmd = cn.createStatement();
                ResultSet resultado = cmd.executeQuery("select * from Cliente where nom = '"+consulta+"' "+
                            "or ape = '"+consulta+"' or mail = '"+consulta+"'");
                //SE TRANSFORMA EL RESULTADO A STRING
                String x = Boolean.toString(resultado.next());
                //SÍ SE ENCONTRÓ UN VALOR...
                if(x.equals("true")){
                    //REMOVER LOS DATOS DE LA LISTA, Y OBTENER LOS NUEVOS DE LA TABLA A MOSTRAR
                    listaClientes.removeAll(listaClientes);
                    do{
                        listaClientes.add(
                            new Clientes(
                                resultado.getInt("id_clie"),
                                resultado.getString("nom"),
                                resultado.getString("ape"),
                                resultado.getInt("edad"),
                                resultado.getString("mail"),
                                resultado.getInt("id_vue")
                            )
                        );
                    }while(resultado.next());
                    cmd.close();
                    resultado.close();
                    //ASIGNAMOS EL RESULTADO DEL QUERY DE LA BUSQUEDA A LA TABLA
                    tblClientes.setItems(listaClientes);
                }
                else{
                    //VENTANA DE QUE NO EXISTE EL VUELO EN LA BASE DE DATOS
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Algo salió demasiado mal...");
                    alert.setHeaderText(null);
                    alert.setContentText("No existe ningún cliente con esos detalles en la base de datos");
                    alert.showAndWait();
                }
            }
            catch(SQLException ex){
                System.out.println(ex);
            }
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // LENAR DATOS A LA TABLA
        llenarDatosTabla(cn,listaClientes);
        tblClientes.setItems(listaClientes);
        
        //CONECTAMOS LOS DATOS A LAS COLUMNAS DE LA TABLA
        colNombre.setCellValueFactory(new PropertyValueFactory<Clientes, String> ("Nombre"));
        colApellidos.setCellValueFactory(new PropertyValueFactory<Clientes, String> ("Apellidos"));
        colContacto.setCellValueFactory(new PropertyValueFactory<Clientes, Date> ("Contacto"));
        colIdVuelo.setCellValueFactory(new PropertyValueFactory<Clientes, String> ("IdVuelo"));
        colEdad.setCellValueFactory(new PropertyValueFactory<Clientes, Integer> ("Edad"));
    }    
    
}
