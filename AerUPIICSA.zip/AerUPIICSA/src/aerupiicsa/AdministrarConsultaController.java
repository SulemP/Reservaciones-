/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aerupiicsa;


import aerupiicsa.Validaciones.EditableIntegerTableCell;
import aerupiicsa.Validaciones.validationTexto;
import static aerupiicsa.Validaciones.validationTexto.validarCorreo;
import static aerupiicsa.Validaciones.validationTexto.validarVacio;
import static aerupiicsa.Validaciones.validationTexto.validar;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.control.cell.TextFieldTreeTableCell;
import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.util.converter.DefaultStringConverter;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.NumberStringConverter;

/**
 * FXML Controller class
 *
 * @author ricardosandoval
 */
public class AdministrarConsultaController extends ConsultarController implements Initializable, validationTexto {

    /*Conexion cc = new Conexion();
    Connection cn = cc.conectar();
    ObservableList<Clientes> listaClientes = FXCollections.observableArrayList();
    ObservableList<Vuelo> listaVuelos = FXCollections.observableArrayList();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    @FXML TableView tblClientes;
    @FXML TableColumn colNombre;
    @FXML TableColumn colIdVuelo;
    @FXML TableColumn colApellidos;
    @FXML TableColumn colContacto;
    @FXML TextField txtBuscar;
    @FXML TextField txtNombre;
    @FXML TextField txtContacto;
    @FXML TextField txtDestino;
    @FXML TextField txtDescripcion;
    @FXML TextField txtIdVuelo;
    @FXML TextField txtFecha;
    @FXML TextField txtHora;
    @FXML TextField txtZona;
    @FXML Button btnImprimir; */
    StringConverter convertidor = new IntegerStringConverter();  
   
    
    @FXML
    public void btnEliminarDatos(ActionEvent e){
        if(tblClientes.getSelectionModel().getSelectedIndex() == -1){
            //VENTANA DE QUE NO SELECCIONO NADA EN LA TABLA
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Algo salió demasiado mal...");
            alert.setHeaderText(null);
            alert.setContentText("Selecciona al cliente que quieres cancelar el vuelo.");
            alert.showAndWait();
        }
        else{
            
        try{
            //SE HACE LA INSTRUCCION DE DELETE  
            Statement cmd = cn.createStatement();
            cmd.execute(
                "delete Cliente from Cliente where id_clie = "+listaClientes.get(tblClientes.getSelectionModel().getSelectedIndex()).getIdCliente()
            );
            
            cmd.execute(
                    "alter table Cliente auto_increment = 1"
            );

            //MUESTRA VENTANA DE CONFIRMACION
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmación");
            alert.setHeaderText(null);
            alert.setContentText("Se canceló la reserva con éxito");
            alert.showAndWait();
        
            
            listaClientes.removeAll(listaClientes); //REMUEVE ELEMENTOS DE LA LISTA
            llenarDatosTabla(cn,listaClientes); //SE VUELVEN A CAPTURAR LOS CAMPOS DE LA BD
            tblClientes.refresh(); //ACTUALIZA LOS DATOS DE LA TABLA
            txtBuscar.clear();
            txtNombre.clear();
            txtContacto.clear();
            txtDestino.clear();
            txtDescripcion.clear();
            txtIdVuelo.clear();
            txtFecha.clear();
            txtHora.clear();
            txtZona.clear();
            btnImprimir.setDisable(true);
            cmd.close();
        } catch(SQLException ex){
            System.out.println(ex);
        }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        // LENAR DATOS A LA TABLA
        llenarDatosTabla(cn,listaClientes);
        tblClientes.setItems(listaClientes);
        
        //CONECTAMOS LOS DATOS A LAS COLUMNAS DE LA TABLA
        colNombre.setCellValueFactory(new PropertyValueFactory<Clientes, String> ("Nombre"));
        colApellidos.setCellValueFactory(new PropertyValueFactory<Clientes, String> ("Apellidos"));
        colContacto.setCellValueFactory(new PropertyValueFactory<Clientes, Date> ("Contacto"));
        colIdVuelo.setCellValueFactory(new PropertyValueFactory<Clientes, String> ("IdVuelo"));
        colEdad.setCellValueFactory(new PropertyValueFactory<Clientes, Integer> ("Edad"));
        
        tblClientes.setEditable(true);
        colNombre.setCellFactory(TextFieldTableCell.forTableColumn());
        colNombre.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Clientes,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Clientes,String> t){
                        if(validarVacio(t.getNewValue()) || validar(t.getNewValue())){
                            //MUESTRA VENTANA DE ERROR
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Algo salió demasiado mal...");
                            alert.setHeaderText(null);
                            alert.setContentText("Formato incorrecto, vuelve a intentarlo.");
                            alert.showAndWait();
                            tblClientes.refresh();
                        } else{
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Cliente set nom= '"+t.getNewValue()+"' where id_clie= "+listaClientes.get(t.getTablePosition().getRow()).getIdCliente()
                                    
                            );
                            cmd.close();
                            
                        ((Clientes)t.getTableView().getItems().get(t.getTablePosition().getRow())).setNombre(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                        
                        }
                    }
                }
        );
        
        colApellidos.setCellFactory(TextFieldTableCell.forTableColumn());
        colApellidos.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Clientes,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Clientes,String> t){
                        if(validarVacio(t.getNewValue()) || validar(t.getNewValue())){
                            //MUESTRA VENTANA DE ERROR
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Algo salió demasiado mal...");
                            alert.setHeaderText(null);
                            alert.setContentText("Formato incorrecto, vuelve a intentarlo.");
                            alert.showAndWait();
                            tblClientes.refresh();
                        } else{
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Cliente set ape= '"+t.getNewValue()+"' where id_clie= "+listaClientes.get(t.getTablePosition().getRow()).getIdCliente()
                                    
                            );
                            cmd.close();
                        ((Clientes)t.getTableView().getItems().get(t.getTablePosition().getRow())).setApellidos(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                        
                        }
                    }
                }
        );
        
        colContacto.setCellFactory(TextFieldTableCell.forTableColumn());
        colContacto.setOnEditCommit(
                new EventHandler <TableColumn.CellEditEvent<Clientes,String>>(){
                    @Override
                    public void handle (TableColumn.CellEditEvent<Clientes,String> t){
                        if(validarVacio(t.getNewValue()) || !validarCorreo(t.getNewValue())){
                            //MUESTRA VENTANA DE ERROR
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Algo salió demasiado mal...");
                            alert.setHeaderText(null);
                            alert.setContentText("Formato incorrecto, vuelve a intentarlo.");
                            alert.showAndWait();
                            tblClientes.refresh();
                        } else{
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Cliente set mail= '"+t.getNewValue()+"' where id_clie= "+listaClientes.get(t.getTablePosition().getRow()).getIdCliente()
                                    
                            );
                            cmd.close();
                            
                        ((Clientes)t.getTableView().getItems().get(t.getTablePosition().getRow())).setContacto(t.getNewValue());
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        }
                        
                        }
                    }
                }
        );
        
        
        //colEdad.setOnEditCommit(value);
        colEdad.setCellFactory(TextFieldTableCell.forTableColumn(convertidor));
        colEdad.setCellFactory(col -> new EditableIntegerTableCell<Integer>());
        colEdad.setOnEditCommit(
                
                new EventHandler <TableColumn.CellEditEvent<Clientes,Integer>>(){
                    
                    @Override
                    public void handle (TableColumn.CellEditEvent<Clientes,Integer> t){
                        
                        try {
                            Statement cmd = cn.createStatement();
                            cmd.execute(
                                    
                                    "update Cliente set edad= "+t.getNewValue()+" where id_clie= "+listaClientes.get(t.getTablePosition().getRow()).getIdCliente()
                                    
                            );
                            ((Clientes)t.getTableView().getItems().get(t.getTablePosition().getRow())).setEdad(t.getNewValue());
                            cmd.close();
                        } catch (SQLException ex) {
                            System.err.println(ex);
                        } 
                        
                    }
                    
                
                }
                        
        );
        
    }    
    
}
